create FUNCTION baiat(id1 IN number)  
RETURN number 
IS 
    baiat number; 
BEGIN
  select count(id) into baiat from studenti where studenti.prenume not like '%a' and studenti.id=id1;
  return baiat;
END;
/


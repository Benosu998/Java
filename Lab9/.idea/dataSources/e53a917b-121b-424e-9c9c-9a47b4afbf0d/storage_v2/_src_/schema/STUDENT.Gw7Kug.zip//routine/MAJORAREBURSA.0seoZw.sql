create PROCEDURE majorareBursa(idS IN studenti.id%TYPE) AS
  bursaM NUMBER;
  Over3000E EXCEPTION;
  PRAGMA EXCEPTION_INIT (Over3000E, -20001);
  BEGIN
      SELECT nvl(bursa,0) INTO bursaM FROM STUDENTI WHERE ID = idS;
      bursaM := bursaM + 2500;
      IF(bursaM > 3000) THEN
        UPDATE STUDENTI SET bursa = 3000 WHERE ID = idS;
        RAISE Over3000E;
      ELSE
        UPDATE STUDENTI SET bursa = bursaM WHERE ID = idS;
      END IF;
  END;
/


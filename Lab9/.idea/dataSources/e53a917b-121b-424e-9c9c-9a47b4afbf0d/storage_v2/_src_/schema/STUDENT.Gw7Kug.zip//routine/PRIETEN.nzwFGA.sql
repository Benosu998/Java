create FUNCTION prieten(id1 IN number, id2 IN number)  
RETURN number 
IS 
    prietenie number; 
BEGIN 
    
    select count(id) into prietenie from prieteni  
    where prieteni.id_student1=id1 and prieteni.id_student2=id2 ;
    return prietenie;
END;
/


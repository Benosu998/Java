create trigger LOG_UPDATE
  after insert or update of VALOARE or delete
  on NOTE
  for each row
begin
        case
            when updating then
                insert into LOGuri values (:old.ID, :old.VALOARE, :new.VALOARE , 'UPDATE' ,current_timestamp ,(select user from dual));
            when inserting then
                insert into LOGuri values (null, null, :new.VALOARE , 'INSERTING' ,current_timestamp , (select user from dual));
            when deleting then
                insert into LOGuri values (:old.id , :old.VALOARE , null,  'DELETE' , current_timestamp , (select user from dual));
            end case;
        
end LOG_UPDATE;
/


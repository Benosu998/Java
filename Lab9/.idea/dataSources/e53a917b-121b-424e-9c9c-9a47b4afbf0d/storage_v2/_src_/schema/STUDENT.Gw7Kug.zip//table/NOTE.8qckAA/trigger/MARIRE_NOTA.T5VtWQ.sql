create trigger MARIRE_NOTA
  before update of VALOARE
  on NOTE
  for each row
BEGIN
  dbms_output.put_line('ID nota: ' || :OLD.id); -- observati ca aveti acces si la alte campuri, nu numai la cele modificate...
  dbms_output.put_line('Vechea nota: ' || :OLD.valoare);  
  dbms_output.put_line('Noua nota: ' || :NEW.valoare);    

  -- totusi nu permitem sa facem update daca valoarea este mai mica (conform regulamentului universitatii):
  IF (:OLD.valoare>:NEW.valoare) THEN :NEW.valoare := :OLD.valoare;
  end if;  
END;
/


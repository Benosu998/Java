create trigger DML_STUD1
  before insert or update or delete
  on STUDENTI
declare   
   v_nume studenti.nume%type;
BEGIN  
  select nume into v_nume from studenti where id=200;
  dbms_output.put_line('Before DML TRIGGER: ' || v_nume);
END;
/

